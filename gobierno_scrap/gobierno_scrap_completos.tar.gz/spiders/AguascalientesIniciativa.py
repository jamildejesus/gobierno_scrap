import scrapy



class CampecheGacetaSpider(scrapy.Spider):
    name = "AguasccalientesIniciativa"
    allowed_domains = ["congresoags.gob.mx"]
    start_urls = ["https://congresoags.gob.mx/agenda_legislativa/iniciativas"]


    def parse(self, response):

        agendas = [
            "//div[@id='tabs-66']//table[@id='datatable-agenda']//tbody/tr",
            "//div[@id='tabs-65']//table[@id='datatable-agenda1']//tbody/tr",
            "//div[@id='tabs-64']//table[@id='datatable-agenda2']//tbody/tr"
        ]
        i=0
        while(i<len(agendas)):
            rows = response.xpath(agendas[i])
            for row in rows:
                tds = row.xpath(".//td")
                contenido = tds[2].xpath("text()").get()
                fecha = tds[4].xpath(".//span/text()").get()
                recurso = tds[6].xpath(".//a/@href").get()

                print(recurso)
            i = i + 1;    
